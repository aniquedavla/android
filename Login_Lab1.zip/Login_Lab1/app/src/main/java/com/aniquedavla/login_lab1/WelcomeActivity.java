package com.aniquedavla.login_lab1;

public class WelcomeActivity {
}
